<?php
// array didalam array (assosiatif)
$DATA_MAHASISWA = array(
    "Bagus" => array(
        "nilai1" => 80,
        "nilai2" => 70,
        "nilai3" => 60
    )
);

// mengakses nilai-nilai dalam array asosiatif
foreach ($DATA_MAHASISWA as $nama => $nilai) {
    echo "$nama:\n";
    foreach ($nilai as $kunci => $nilai_individu) {
        echo "$kunci: $nilai_individu \n";
    }
}
?>

